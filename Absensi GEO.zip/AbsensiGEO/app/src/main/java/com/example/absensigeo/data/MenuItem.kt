package com.example.absensigeo.data

data class MenuItem(
    val title: String,
    val iconRes: Int
)