package com.example.absensigeo.data

data class BuktiMengajar(
    val tanggal: String = "",
    val nama_file: String = "",
    val url: String = "",
    val materi: String = "",
    val deskripsi: String = ""
)
