package com.example.absensigeo.data

data class TemplateSuratModel(
    val judul: String = "",
    val url: String = "",
    val timestamp: Long = 0
)
